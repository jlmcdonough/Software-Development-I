/* 
 * Joseph McDonough and Patrick McNamara
 * Lab 5
 * 21 February 2019
 */
package lab5;

import java.util.*;
import java.io.*;


public class ShapeTester 
{
	public static void main(String[] args) throws IOException
	{
		Scanner in = new Scanner(System.in);
		ShapeTester what = new ShapeTester();
		System.out.println(what.printData());
		//System.out.println(tester.toString());
		in.close(); 
		
	}
private String data;
public ShapeTester()
{
	File file = new File("Shapes.txt");
	Scanner in = new Scanner(System.in);
	String data = in.nextLine();
}
public String printData()
{
	return data;
}

/*	
	
	
	
	String fileName = "Shapes.txt";
	FileReader fileReader = new FileReader(fileName);
	BufferedReader bufferedReader = new BufferedReader(fileReader);
	//Scanner infile = new Scanner(new FileReader("Shapes.txt"));
	String data = fileReader.readLine();
/*	if(data[0].equals("Sphere"))
	{
		Sphere temp = new Sphere(data[1]);
	}
	else if(data[0].equals("Cylinder"))
		{
			Cylinder temp = new Cylinder(data[1], data[2]);
		}
	*/
	/*
	String part1,part2;
	part1,part2 = data.split(" ",1);
	part2 = Integer.parseInt(part2);
	if(part1.equals("Sphere"))
	{
		Sphere temp = new Sphere(part2);
	}
	else if(part1.equals("Cylinder"))
	{
		String part3 = part2.split(" ",1);
		part3 = Integer.parseInt(part3);
		Cylinder temp = new Cylinder(part2, part3);
	}*/
		


	
public String toString()
{
	return this.toString();
} 
}
