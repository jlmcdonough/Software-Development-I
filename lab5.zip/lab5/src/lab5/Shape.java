/* 
 * Joseph McDonough and Patrick McNamara
 * Lab 5
 * 21 February 2019
 */

package lab5;

//******************************************************************************
//Shape.java       Java Foundations
//
//Solution to Programming Project 8.6
//******************************************************************************

public abstract class Shape
{
abstract public double computeArea();
abstract public double computePerimeter();
}