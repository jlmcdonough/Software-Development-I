/* 
 * Joseph McDonough and Patrick McNamara
 * Lab 5
 * 21 February 2019
 */
package lab5;

import java.text.*;

public class Cylinder extends Shape 
{
	protected double height;
	protected double radius;
	protected static DecimalFormat form = new DecimalFormat("0.##");
	
	public Cylinder(double h, double r)
	{
		height = h;
		radius = r;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public double computeArea()
	{
		double circleArea = 2 * Math.PI * (radius * radius);
		double otherPart = 2 * Math.PI * radius * height;
		double answer = circleArea + otherPart;
		return answer;
	}
	
	public double computePerimeter()
	{
		double diameter = radius + radius;
		return (2*diameter) + (2*height);
	}
	
	public double computeVolume()
	{
		return Math.PI * radius * radius * height;
	}

	public String toString() 
	{
	  return "Cylinder: Height is " + form.format(height) +
	         "\nPerimeter of base is " + form.format(computePerimeter()) +
	         ", area is " + form.format(computeArea()) + "\nVolume is " + 
	         form.format(computeVolume()); 
	}
}
