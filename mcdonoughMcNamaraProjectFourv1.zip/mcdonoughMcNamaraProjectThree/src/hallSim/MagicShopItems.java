//Joseph McDonough and Patrick McNamara
package hallSim;

public class MagicShopItems {
	
	private String itemName;
	private int itemCost;
	
	public MagicShopItems(String n, int g)
	{
		this.itemName = n;
		this.itemCost = g;
	}
	
	public String getName()
	{
		return itemName;
	}
	
	public int getCost()
	{
		return itemCost;
	}
	
	public String toString()
	{
		String res = ("Item: " + itemName + " Cost: " + itemCost);
		return res;
	}

}
