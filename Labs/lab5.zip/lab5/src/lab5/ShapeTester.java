/* 
 * Joseph McDonough and Patrick McNamara
 * Lab 5
 * 21 February 2019
 */
package lab5;

import java.util.*;
import java.io.*;


public class ShapeTester
{
	public static void main(String[] args) throws IOException
	{
        Scanner in = new Scanner(System.in);
        File file = new File("Shapes.txt");
        in = new Scanner(file);
        Shape[] listOfShapes = new Shape[4];
        int i = 0;
        while (in.hasNextLine()) 
        {
            String data = in.nextLine();
            String[] type = data.split(" ");
        	if(type[0].equals("Sphere"))
        	{
                	Sphere temp1 = new Sphere(Double.parseDouble(type[1]));
                	listOfShapes[i] = temp1;
        	}
            if(type[0].equals("Cylinder"))
            {
                	Cylinder temp2 = new Cylinder(Double.parseDouble(type[1]),Double.parseDouble(type[2]));
                	listOfShapes[i] = temp2;
            }
            i++;
        }
		in.close(); 
		for(Shape j:listOfShapes)
		{
			System.out.println(j.toString());
			System.out.println();
		}
		
	}
}