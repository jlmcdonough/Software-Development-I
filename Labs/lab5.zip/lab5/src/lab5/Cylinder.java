/* 
 * Joseph McDonough and Patrick McNamara
 * Lab 5
 * 21 February 2019
 */
package lab5;

import java.text.*;

public class Cylinder extends Shape 
{
	protected double height;
	protected double radius;
	protected static DecimalFormat form = new DecimalFormat("0.##");
	
	public Cylinder(double h, double r)  //height is listed in the toString so assuming it is the first value passed as directions never stated otherwise
	{
		height = h;
		radius = r;
	}
	
	public double getHeight()
	{
		return height;
	}
	
	public double getRadius()
	{
		return radius;
	}
	
	public double computeArea()
	{
		double circleArea = 2 * Math.PI * (radius * radius);
		double otherPart = 2 * Math.PI * radius * height;
		double answer = circleArea + otherPart;
		return answer;
	}
	
	public double computePerimeter() //output says perimeter of base so that's what is calculated, not perimeter of whole cylinder
	{
		//perimeter of the base of a cylinder is simply the circumference of the cirlce
		return 2 * radius * Math.PI;
	}
	
	public double computeVolume()
	{
		return Math.PI * radius * radius * height;
	}

	public String toString() 
	{
	  return "Cylinder: Height is " + form.format(height) +
	         ",\nPerimeter of base is " + form.format(computePerimeter()) +
	         ", Area is " + form.format(computeArea()) + ",\nVolume is " + 
	         form.format(computeVolume()); 
	}
}
