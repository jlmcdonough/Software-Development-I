/**
 * Joseph McDonough and Patrick McNamara
 * CMPT 220L-200
 * 25 April 2019
 * Lab 10
 */

package lab10;

public class Card {
	
	private String number;
	private String suit;
	private int numIndex;
	private int suitIndex;
	
	/**
	 * 
	 * @param n - number of the card
	 * @param s - suit of the card
	 * @param nI - index of the number in the array - used for easy in comparing the numbers of each card
	 * @param sI - index of the suit in the array - used for easy in comparing the suits of each card
	 */
	public Card(String n, String s, int nI, int sI)
	{
		number = n;
		suit=s;
		numIndex = nI;
		suitIndex = sI;
	}
	
	/**
	 * 
	 * @return - returns the actual number of the card
	 */
	public String getNumber()
	{
		return number;
	}
	
	/**
	 * 
	 * @return - returns the actual suit of the card
	 */
	public String getSuit()
	{
		return suit;
	}
	
	/**
	 * 
	 * @return - returns index of the number array
	 */
	public int getNumberIndex()
	{
		return numIndex;
	}

	/**
	 * 
	 * @return - returns index of the suit array
	 */
	public int getSuitIndex()
	{
		return suitIndex;
	}
	
	/**
	 * 
	 * @param c2 - object is c1 so its checking c1 to c2 in the main method
	 * @return - returns true if the cards are different(what is desired). Returns false if the cards are identical
	 */
	public boolean checkCards(Card c2)
	{
		if(this.getNumber().equals(c2.getNumber()))  //checks to see if the number on the cards are the same
		{
			if(this.getSuit().equals(c2.getSuit()))  //checks to see if the suits on the cards are the same
			{
				return false;
			}
		}
		return true;
	}
	
	/**
	 * 
	 * @param n1 - number of the card
	 */
	public void setNumber(String n1)
	{
		number = n1;
	}
	
	/**
	 * 
	 * @param s1 - suit of the card
	 */
	public void setSuit(String s1)
	{
		suit = s1;
	}
	
	/**
	 * 
	 * @param n2 - index for the number of the card
	 */
	public void setNumberIndex(int n2)
	{
		numIndex = n2;
	}
	
	/**
	 * 
	 * @param s2 - index for the suit of the card
	 */
	public void setSuitIndex(int s2)
	{
		suitIndex = s2;
	}
	
	/**
	 * @return - returns the number and suit of the card calling it
	 */
	public String toString()
	{
		String res = "is the " + this.getNumber() + " of " + this.getSuit() + ".";
		return res;
	}
}
